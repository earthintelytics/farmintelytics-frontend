/**
 * Estates of the signed-in organisation — contract in docs/WORK_SPLIT.md
 * ("Estates"). Built by the backend team; until GET /estates exists the
 * portal falls back to the estate names carried by the plots.
 */
import { NotConnectedError } from './datasetsApi';
import { API_BASE } from './apiBase';
import { responseError } from './apiError';


// Until the backend ships GET /estates, remember that for the browser session
// so every page load does not repeat a 404.
const UNAVAILABLE = 'fi_estates_unavailable';

export async function fetchEstates() {
  if (sessionStorage.getItem(UNAVAILABLE)) throw new NotConnectedError();
  const token = localStorage.getItem('fi_token');
  let res;
  try {
    const m = (() => { try { return sessionStorage.getItem('fi_module'); } catch { return null; } })();
    res = await fetch(`${API_BASE}/estates${m ? `?module=${encodeURIComponent(m)}` : ''}`, { cache: 'no-store', headers: token ? { Authorization: `Bearer ${token}` } : {} });
  } catch {
    throw new NotConnectedError();
  }
  if (res.status === 404 || res.status === 405 || !(res.headers.get('content-type') || '').includes('json')) {
    sessionStorage.setItem(UNAVAILABLE, '1');
    throw new NotConnectedError();
  }
  if (!res.ok) throw await responseError(res);
  return res.json();
}
