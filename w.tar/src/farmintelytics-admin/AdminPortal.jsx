import { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import {
  Building2,
  Key,
  Activity,
  PlayCircle,
  LayoutDashboard,
  LogOut,
  Menu,
  X,
  Clock,
  Database,
  Rocket,
  SlidersHorizontal,
  Sparkles,
  ShieldCheck,
  LifeBuoy,
  Radio,
  Mail,
  Shield,
  FileText,
} from 'lucide-react';

import Onboarding from './pages/Onboarding';
import CropThresholds from './pages/CropThresholds';
import Organizations from './pages/Organizations';
import Credentials from './pages/Credentials';
import Logs from './pages/Logs';
import Scheduler from './pages/Scheduler';
import Inventory from './pages/Inventory';
import AiSettings from './pages/AiSettings';
import PipelineRuns from './pages/PipelineRuns';
import TeamAccounts from './pages/TeamAccounts';
import ProblemReports from './pages/ProblemReports';
import Integrations from './pages/Integrations';
import EmailLog from './pages/EmailLog';
import ProtectedAreas from './pages/ProtectedAreas';
import SystemStatus from './pages/SystemStatus';
import ActivityLog from './pages/Activity';
import { fetchSystemStatus } from '../services/adminApi';
import { hasValidTeamToken, redirectToTeamSignIn, teamRole, TEAM_ROLES } from '../services/session';
import { ConfirmProvider } from './components/ConfirmProvider';

// Grouped by what the team is doing: setting clients up, running the
// platform, or tuning how data is interpreted. `owner` pages are only for
// team owners (the server refuses the others too).
const NAV_GROUPS = [
  { label: 'Setup', items: [
    { id: 'onboarding',    label: 'Onboard organisation', icon: Rocket,    path: '/admin/onboarding' },
    { id: 'organizations', label: 'Organisations',        icon: Building2, path: '/admin/organizations' },
    { id: 'credentials',   label: 'Sign-in details',      icon: Key,       path: '/admin/credentials' },
    { id: 'team',          label: 'Team accounts',        icon: ShieldCheck, path: '/admin/team', owner: true },
  ]},
  { label: 'Operations', items: [
    { id: 'status',        label: 'System status',        icon: Activity,  path: '/admin/system-status' },
    { id: 'scheduler',     label: 'Monitoring schedule',  icon: Clock,     path: '/admin/scheduler' },
    { id: 'runs',          label: 'Pipeline runs',        icon: PlayCircle,  path: '/admin/runs' },
    { id: 'inventory',     label: 'Storage',              icon: Database,  path: '/admin/inventory' },
    { id: 'activity',      label: 'Activity',             icon: FileText,  path: '/admin/activity' },
    { id: 'emaillog',      label: 'Email log',            icon: Mail,      path: '/admin/email-log' },
    { id: 'logs',          label: 'Logs',                 icon: Activity,  path: '/admin/logs' },
    { id: 'reports',       label: 'Problem reports',      icon: LifeBuoy,  path: '/admin/reports' },
  ]},
  { label: 'Configuration', items: [
    { id: 'thresholds',      label: 'Map classes',     icon: SlidersHorizontal, path: '/admin/thresholds' },
    { id: 'protected-areas', label: 'Protected areas', icon: Shield,            path: '/admin/protected-areas' },
    { id: 'ai',              label: 'AI settings',     icon: Sparkles,          path: '/admin/ai', owner: true },
    { id: 'integrations',    label: 'Integrations',    icon: Radio,             path: '/admin/integrations', owner: true },
  ]},
];
const NAV_ITEMS = NAV_GROUPS.flatMap(g => g.items);

const AdminPortal = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [systemHealth, setSystemHealth] = useState(null);
  const adminEmail = localStorage.getItem('fi_admin_email') || '';
  const role = teamRole();
  const groups = NAV_GROUPS.map((g) => ({ ...g, items: g.items.filter((i) => !i.owner || role === 'owner') })).filter((g) => g.items.length);
  const ownerOnly = (el) => (role === 'owner' ? el : (
    <div className="max-w-xl mx-auto px-6 py-16 text-center">
      <h1 className="font-display text-2xl font-semibold text-gray-900">Only team owners can open this page</h1>
      <p className="text-sm text-gray-500 mt-2">Your role is {TEAM_ROLES[role]?.label || 'not set'}. Ask a team owner if you need it.</p>
    </div>
  ));

  useEffect(() => {
    // An outdated or missing team sign-in goes to the sign-in page, not to "Forbidden".
    if (!hasValidTeamToken()) redirectToTeamSignIn();

    // Check system status for top red alert banner (T38)
    let isMounted = true;
    const checkHealth = () => {
      fetchSystemStatus()
        .then((res) => { if (isMounted) setSystemHealth(res); })
        .catch(() => {});
    };
    checkHealth();
    const timer = setInterval(checkHealth, 30000);
    return () => { isMounted = false; clearInterval(timer); };
  }, [navigate]);

  const handleSignOut = () => {
    localStorage.removeItem('fi_admin_token');
    localStorage.removeItem('fi_admin_email');
    navigate('/admin-engine');
  };

  const activeId = NAV_ITEMS.find(n => location.pathname.startsWith(n.path))?.id || 'organizations';

  const activeItem = NAV_ITEMS.find(n => n.id === activeId);
  const activeAlertsCount = systemHealth?.active_alerts_count || 0;
  const isSystemDegraded = systemHealth?.status === 'degraded' || systemHealth?.status === 'unhealthy';

  return (
    <ConfirmProvider>
    <div className="relative flex h-screen overflow-hidden bg-[var(--bg-main)] text-[var(--text-main)] font-sans">

      {/* ── Sidebar ── */}
      <aside className={`relative flex flex-col shrink-0 bg-white border-r border-gray-200 transition-[width] duration-200 ${sidebarOpen ? 'w-64' : 'w-[68px]'}`}>
        <div className={`h-16 flex items-center gap-3 border-b border-gray-200 ${sidebarOpen ? 'px-5' : 'justify-center'}`}>
          <img src="/farmintelytics-logo.png" alt="FarmIntelytics" className="h-9 w-9 object-contain shrink-0" width="36" height="36" />
          {sidebarOpen && (
            <div className="leading-tight min-w-0">
              <p className="font-display text-sm font-semibold truncate">FarmIntelytics</p>
              <p className="text-xs text-[var(--text-muted)]">Admin console</p>
            </div>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {groups.map(group => (
            <div key={group.label}>
              {sidebarOpen && <p className="px-3 mb-2 text-xs font-medium text-gray-400">{group.label}</p>}
              <div className="space-y-0.5">
                {group.items.map(item => {
                  const active = activeId === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => navigate(item.path)}
                      title={!sidebarOpen ? item.label : undefined}
                      className={`w-full flex items-center gap-3 rounded-[10px] text-sm transition-colors ${sidebarOpen ? 'px-3 py-2' : 'justify-center py-2.5'} ${
                        active ? 'bg-green-50 text-green-800 font-medium' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <item.icon size={17} className={`shrink-0 ${active ? 'text-[var(--brand-primary)]' : ''}`} />
                      {sidebarOpen && <span className="truncate">{item.label}</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-3 border-t border-gray-200 space-y-1">
          {sidebarOpen && (
            <div className="px-3 py-2">
              <p className="text-xs text-gray-400">Signed in as</p>
              <p className="text-sm text-gray-700 truncate">{adminEmail}</p>
              {role && <p className="text-xs font-medium text-green-800 mt-0.5">{TEAM_ROLES[role].label}</p>}
            </div>
          )}
          <button onClick={() => navigate('/platformhub')} title="Platform hub"
            className={`w-full flex items-center gap-3 rounded-[10px] text-sm text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors ${sidebarOpen ? 'px-3 py-2' : 'justify-center py-2.5'}`}>
            <LayoutDashboard size={17} className="shrink-0" />{sidebarOpen && 'Platform hub'}
          </button>
          <button onClick={handleSignOut} title="Sign out"
            className={`w-full flex items-center gap-3 rounded-[10px] text-sm text-gray-600 hover:bg-red-50 hover:text-red-700 transition-colors ${sidebarOpen ? 'px-3 py-2' : 'justify-center py-2.5'}`}>
            <LogOut size={17} className="shrink-0" />{sidebarOpen && 'Sign out'}
          </button>
        </div>

        <button onClick={() => setSidebarOpen(!sidebarOpen)} aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          className="absolute top-5 -right-3 w-6 h-6 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-500 hover:text-gray-900 z-30">
          {sidebarOpen ? <X size={12} /> : <Menu size={12} />}
        </button>
      </aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Slim breadcrumb: each page renders its own title, counts and actions */}
        <header className="shrink-0 h-12 flex items-center bg-white border-b border-gray-200 px-8 text-sm">
          <span className="text-gray-400">Admin console</span>
          {activeItem && <>
            <span className="mx-2 text-gray-300">/</span>
            <span className="text-gray-400">{NAV_GROUPS.find(g => g.items.includes(activeItem))?.label}</span>
            <span className="mx-2 text-gray-300">/</span>
            <span className="font-medium text-gray-800">{activeItem.label}</span>
          </>}
        </header>

        {/* ── Red status alert line on admin console (T38) ── */}
        {(activeAlertsCount > 0 || isSystemDegraded) && (
          <div className="shrink-0 bg-red-50 border-b border-red-200 px-8 py-2.5 flex items-center justify-between text-xs text-red-900">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse shrink-0" />
              <span className="font-semibold">System attention required:</span>
              <span>
                {activeAlertsCount > 0
                  ? `${activeAlertsCount} active operational issue(s) detected (${systemHealth.active_alerts[0]?.title}).`
                  : 'Platform health degraded. Check system services.'}
              </span>
            </div>
            <button
              onClick={() => navigate('/admin/system-status')}
              className="font-medium underline hover:text-red-950 shrink-0 ml-4"
            >
              View system status →
            </button>
          </div>
        )}

        {role === 'support' && (
          <p className="shrink-0 px-8 py-2 bg-amber-50 border-b border-amber-200 text-sm text-amber-900">Support access: you can look at everything, but changes will be refused.</p>
        )}
        <main className="relative flex-1 overflow-auto">
          <Routes>
            <Route index element={<Navigate to="organizations" replace />} />
            <Route path="onboarding"    element={<Onboarding />} />
            <Route path="team"          element={ownerOnly(<TeamAccounts />)} />
            <Route path="organizations" element={<Organizations />} />
            <Route path="system-status" element={<SystemStatus />} />
            <Route path="inventory"     element={<Inventory />} />
            <Route path="credentials"   element={<Credentials />} />
            <Route path="scheduler"     element={<Scheduler />} />
            <Route path="runs"          element={<PipelineRuns />} />
            <Route path="email-log"     element={<EmailLog />} />
            <Route path="activity"        element={<ActivityLog />} />
            <Route path="thresholds"      element={<CropThresholds />} />
            <Route path="protected-areas" element={<ProtectedAreas />} />
            <Route path="ai"              element={ownerOnly(<AiSettings />)} />
            <Route path="integrations"    element={ownerOnly(<Integrations />)} />
            <Route path="logs"            element={<Logs />} />
            <Route path="reports"         element={<ProblemReports />} />
          </Routes>
        </main>
      </div>
    </div>
    </ConfirmProvider>
  );
};

export default AdminPortal;

