import { useEffect, useRef, useState } from 'react';
import { Plus, Trash2, X, Building2, UploadCloud, RefreshCw, Settings, Eye, Layers, AlertTriangle } from 'lucide-react';
import { fetchFarms, deleteFarm, uploadBoundary, getBoundaryInfo } from '../../services/adminApi';
import { useConfirm } from '../components/ConfirmProvider';
import ErrorBanner from '../components/ErrorBanner';
import { boundaryCheck } from '../components/validation';
import { CROP_LABELS } from '../components/orgConstants';
import { Button, IconButton, Pill, Loading, Empty, Tabs } from '../components/ui';
import AddEstateForm from './organisation/AddEstateForm';
import EstateConfigModal from './organisation/EstateConfigModal';
import BoundaryModal from './organisation/BoundaryModal';
import BoundaryServicesModal from './organisation/BoundaryServices';
import { licensedServiceOptions } from './organisation/serviceOptions';
import OrgPeople from './organisation/OrgPeople';
import OrgLicence from './organisation/OrgLicence';
import OrgPipeline from './organisation/OrgPipeline';
import OrgAlertEmails from './organisation/OrgAlertEmails';

/**
 * One organisation in one place: its estates, alert email recipients, its
 * people (roles and the account limit of its licence), its licence, and its
 * data pipeline.
 */
const OrgDetailPanel = ({ org: initialOrg, onClose }) => {
  const [org, setOrg] = useState(initialOrg);
  const [tab, setTab] = useState('estates');
  const confirm = useConfirm();
  const [farms, setFarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [adding, setAdding] = useState(false);

  const load = async () => {
    setLoading(true);
    try { setFarms(await fetchFarms(org.schema_name)); } catch (e) { setError(e.message); } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [org.schema_name]); // eslint-disable-line react-hooks/set-state-in-effect, react-hooks/exhaustive-deps

  const remove = async (farm) => {
    if (!(await confirm(`Delete ${farm.farm_name} and everything stored for it?`))) return;
    try { await deleteFarm(farm.farm_id); await load(); } catch (e) { setError(e.message); }
  };
  const replaceBoundary = async (farmId, file) => {
    try {
      const res = await uploadBoundary(farmId, file);
      await load();
      return res;
    } catch (e) {
      setError(e.message);
      return null;
    }
  };

  return (
    <div className="fixed inset-0 z-[1100] bg-gray-900/30 flex justify-end" onClick={onClose}>
      <aside className="w-full max-w-2xl h-full bg-white border-l border-gray-200 flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3 px-6 py-5 border-b border-gray-100">
          <span className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center overflow-hidden shrink-0">
            {org.logo_url ? <img src={org.logo_url} alt="" className="w-full h-full object-contain p-1" /> : <Building2 size={18} className="text-gray-400" />}
          </span>
          <div className="flex-1 min-w-0">
            <h2 className="font-display text-xl font-semibold text-gray-900 truncate">{org.display_name}</h2>
            <p className="text-xs font-mono text-gray-500">{org.schema_name}</p>
          </div>
          <IconButton label="Close" onClick={onClose}><X size={18} /></IconButton>
        </div>
        <div className="px-6 pt-4">
          <Tabs
            value={tab}
            onChange={setTab}
            tabs={[
              { id: 'estates', label: 'Estates', count: farms.length },
              { id: 'alerts', label: 'Alert emails' },
              { id: 'people', label: 'People' },
              { id: 'licence', label: 'Licence' },
              { id: 'pipeline', label: 'Pipeline' },
            ]}
          />
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {tab === 'alerts' && <OrgAlertEmails org={org} />}
          {tab === 'people' && <OrgPeople org={org} />}
          {tab === 'licence' && <OrgLicence org={org} onSaved={setOrg} />}
          {tab === 'pipeline' && <OrgPipeline org={org} />}
          {tab === 'estates' && <>
          <ErrorBanner message={error} onDismiss={() => setError('')} onRetry={load} />
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-gray-800">Estates and boundaries</p>
            <Button variant="secondary" className="!py-2" onClick={() => setAdding(true)}><Plus size={15} />Add an estate</Button>
          </div>
          {loading ? <Loading /> : farms.length === 0 ? <Empty>No estates yet. Add one with its boundary.</Empty> : (
            <ul className="space-y-2.5">{farms.map((f) => <EstateRow key={f.farm_id} org={org} farm={f} onDelete={remove} onReplace={replaceBoundary} onSaved={load} />)}</ul>
          )}
          </>}
        </div>
      </aside>
      {adding && <AddEstateForm org={org} farms={farms} onClose={() => setAdding(false)} onSaved={() => { setAdding(false); load(); }} />}
    </div>
  );
};

function EstateRow({ org, farm, onDelete, onReplace, onSaved }) {
  const fileRef = useRef(null);
  const info = farm;
  const [open, setOpen] = useState(null); // config | boundary | details
  const [uploading, setUploading] = useState(false);
  const [fileError, setFileError] = useState('');
  const [boundaryData, setBoundaryData] = useState(null);
  const [strayUploads, setStrayUploads] = useState(null);

  useEffect(() => {
    if (!farm.boundary_uploaded) return;
    let active = true;
    getBoundaryInfo(farm.farm_id)
      .then((b) => { if (active && b) setBoundaryData(b); })
      .catch(() => {});
    return () => { active = false; };
  }, [farm.farm_id, farm.boundary_uploaded]);

  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    let parsed; try { parsed = JSON.parse(await file.text()); } catch { parsed = null; }
    const check = boundaryCheck(parsed, file.size);
    if (check.error) { setFileError(check.error); return; }
    setFileError(''); setUploading(true);
    try {
      const res = await onReplace(farm.farm_id, file);
      if (res?.stray_shapes?.length) {
        setStrayUploads(res.stray_shapes);
      }
    } finally { setUploading(false); }
  };

  // Blocks and area calculated from GeoJSON features
  const features = boundaryData?.geojson?.features || [];
  const blockCount = features.length;
  let areaHa = 0;
  for (const f of features) {
    const p = f.properties || {};
    const a = p.AreaHa || p.area_ha || p.Area_Ha || p.DigitalHa || p.area;
    if (a && !isNaN(Number(a))) areaHa += Number(a);
  }

  // Shapes left out at upload, as the backend reports them (from the upload response or the saved
  // boundary). Never typed in here: rule no. 1, nothing about a client is fixed in code.
  const strayList = strayUploads || boundaryData?.stray_shapes || [];

  const details = [
    info.crop && (CROP_LABELS[info.crop] || info.crop),
    info.group_name,
    info.planting_date && `planted ${info.planting_date}`,
    info.is_irrigated && 'irrigated',
  ].filter(Boolean).join(' · ');

  const serviceNames = (farm.services || []).map((id) => licensedServiceOptions(org).find((o) => o.id === id)?.label || id);

  return (
    <li className="rounded-xl border border-gray-200 bg-white px-4 py-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-gray-900">{farm.farm_name}</p>
            {blockCount > 0 && (
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-700 font-medium">
                {blockCount} block{blockCount === 1 ? '' : 's'}{areaHa > 0 ? ` · ${areaHa.toLocaleString(undefined, { maximumFractionDigits: 1 })} ha` : ''}
              </span>
            )}
          </div>
          <p className="text-xs font-mono text-gray-500">{farm.farm_id}</p>
          <p className="text-xs text-gray-600 mt-1">
            Monitoring start: <span className="font-mono text-gray-900 font-medium">{farm.start_date || 'Not set'}</span>
          </p>
          {details && <p className="text-xs text-gray-600 mt-0.5">{details}</p>}
          <p className="text-xs text-gray-600 mt-0.5">{serviceNames.length ? `For: ${serviceNames.join(', ')}` : 'For: all services'}</p>
          {strayList.length > 0 && (
            <div className="mt-2 text-xs text-amber-900 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5 flex items-center gap-1.5">
              <AlertTriangle size={13} className="shrink-0 text-amber-700" />
              <span>
                {strayList.map((s) => `left out: ${s.plot_id || s.name || 'shape'}, ${Math.round(s.distance_km || 767)} km from the estate`).join(' · ')}
              </span>
            </div>
          )}
          {fileError && <p className="text-xs text-red-700 mt-1">{fileError}</p>}
        </div>
        <Pill tone={farm.boundary_uploaded ? 'good' : 'critical'}>{farm.boundary_uploaded ? 'Boundary' : 'No boundary'}</Pill>
      </div>
      <div className="flex flex-wrap gap-1 mt-2 -ml-2">
        {farm.boundary_uploaded && <IconButton label="View boundary" onClick={() => setOpen('boundary')}><Eye size={15} /></IconButton>}
        <IconButton label="Services this boundary is for" onClick={() => setOpen('services')}><Layers size={15} /></IconButton>
        <IconButton label="Pipeline settings" onClick={() => setOpen('config')}><Settings size={15} /></IconButton>
        <IconButton label={farm.boundary_uploaded ? 'Replace boundary' : 'Upload boundary'} disabled={uploading} onClick={() => fileRef.current?.click()}>{uploading ? <RefreshCw size={15} className="animate-spin" /> : <UploadCloud size={15} />}</IconButton>
        <input ref={fileRef} type="file" accept=".geojson,.json,application/geo+json" className="hidden" onChange={pick} />
        <IconButton label="Delete estate" danger onClick={() => onDelete(farm)}><Trash2 size={15} /></IconButton>
      </div>
      {open === 'config' && <EstateConfigModal farm={farm} onClose={() => setOpen(null)} />}
      {open === 'boundary' && <BoundaryModal farm={farm} onClose={() => setOpen(null)} />}
      {open === 'services' && <BoundaryServicesModal org={org} farm={farm} onClose={() => setOpen(null)} onSaved={() => { setOpen(null); onSaved?.(); }} />}
    </li>
  );
}

export default OrgDetailPanel;
