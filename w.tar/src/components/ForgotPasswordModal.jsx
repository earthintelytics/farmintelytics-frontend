import { useState } from 'react';
import { X, Mail, KeyRound, Lock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { forgotPassword, resetPassword } from '../services/authApi';

const ForgotPasswordModal = ({ isOpen, onClose, initialEmail = '', onSuccess }) => {
  const [step, setStep] = useState('email'); // 'email' | 'reset'
  const [email, setEmail] = useState(initialEmail);
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (!isOpen) return null;

  const handleRequestCode = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      const res = await forgotPassword(email.trim().toLowerCase());
      setSuccess(res?.message || 'Verification code sent to your email.');
      setStep('reset');
    } catch (err) {
      setError(err?.data?.message || err?.message || 'Failed to send verification code. Please check your email.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (newPassword.length < 8) {
      setError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      const res = await resetPassword({
        email: email.trim().toLowerCase(),
        token: resetCode.trim().toUpperCase(),
        new_password: newPassword,
      });
      setSuccess(res?.message || 'Password reset successfully!');
      if (onSuccess) {
        onSuccess(email, newPassword);
      }
      setTimeout(() => {
        onClose();
        setStep('email');
        setResetCode('');
        setNewPassword('');
        setConfirmPassword('');
      }, 2000);
    } catch (err) {
      setError(err?.data?.message || err?.message || 'Failed to reset password. Please check your verification code.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[2500] flex items-center justify-center bg-gray-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-2xl border border-gray-200 shadow-xl p-6 sm:p-8 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-xl transition-colors"
          aria-label="Close"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
            <KeyRound size={20} />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Reset password</h3>
            <p className="text-xs text-gray-500">
              {step === 'email' ? 'Enter email to receive reset code' : `Code sent to ${email}`}
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="mb-4 flex items-start gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-medium">
            <CheckCircle2 size={15} className="shrink-0 mt-0.5 text-emerald-600" />
            <span>{success}</span>
          </div>
        )}

        {step === 'email' ? (
          <form onSubmit={handleRequestCode} className="space-y-4" method="POST" action="#" name="forgot-password-form">
            <div>
              <label htmlFor="forgot-email" className="block text-xs font-semibold text-gray-700 mb-1">Account email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  id="forgot-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  placeholder="you@organisation.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 bg-white py-2.5 pl-10 pr-3 text-sm outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading || !email}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition-colors disabled:opacity-50 shadow-sm"
            >
              {loading ? 'Sending Code...' : 'Send Verification Code'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleReset} className="space-y-3.5" method="POST" action="#" name="reset-password-form">
            <div>
              <label htmlFor="reset-code" className="block text-xs font-semibold text-gray-700 mb-1">Verification code</label>
              <input
                id="reset-code"
                name="one-time-code"
                type="text"
                required
                autoComplete="one-time-code"
                placeholder="6-character code"
                value={resetCode}
                onChange={(e) => setResetCode(e.target.value.toUpperCase())}
                className="w-full rounded-xl border border-gray-300 bg-white px-3.5 py-2.5 text-sm font-mono outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
              />
            </div>
            <div>
              <label htmlFor="reset-new-password" className="block text-xs font-semibold text-gray-700 mb-1">New password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  id="reset-new-password"
                  name="new-password"
                  type="password"
                  required
                  autoComplete="new-password"
                  minLength={8}
                  placeholder="At least 8 characters"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 bg-white py-2.5 pl-10 pr-3 text-sm outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            </div>
            <div>
              <label htmlFor="reset-confirm-password" className="block text-xs font-semibold text-gray-700 mb-1">Confirm new password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  id="reset-confirm-password"
                  name="confirm-password"
                  type="password"
                  required
                  autoComplete="new-password"
                  minLength={8}
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full rounded-xl border border-gray-300 bg-white py-2.5 pl-10 pr-3 text-sm outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading || !resetCode || !newPassword || !confirmPassword}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition-colors disabled:opacity-50 shadow-sm"
            >
              {loading ? 'Resetting...' : 'Save New Password'}
            </button>
            <button
              type="button"
              onClick={() => setStep('email')}
              className="w-full py-1 text-xs text-gray-500 hover:text-gray-800"
            >
              ← Back to email entry
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPasswordModal;
